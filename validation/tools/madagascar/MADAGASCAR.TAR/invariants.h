
/*  2012 (C) Jussi Rintanen  */

int *onelits;
intset *twolits;

void computeinvariants();
